import java.util.ArrayList;
import java.util.List;

public class IndexNode  {
    String word;
    int occurences;
    List<Integer> list;

    IndexNode left;
    IndexNode right;

    // Constructors
    // Constructor should take in a word and a line number
    // it should initialize the list and set occurrences to 1
    public IndexNode(String word, int line){
        this.word = word;
        this.occurences = 1;
        this.list = new ArrayList<Integer>();
    }

    // Complete This
    // return the word, the number of occurrences, and the lines it appears on.
    // string must be one line
    @Override
    public String toString(){
        return "Word: " + this.word + "\nOccurences: " + this.occurences + "\nLines: " + list.toString();
    }
}