import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

public class DoctorPatientScheduler {

  public static void main(String[] args) {
    // Prompt the user for the name of the text file
    // containing the patient and doctor data.
    // For example, "input.txt".
    System.out.println("Enter the name of the text file:");
    String fileName = System.console().readLine();

    // Read data from the text file and populate doctors and patients maps.
    HashMap<String, Integer> doctors = new HashMap<>();
    HashMap<String, Integer> patients = new HashMap<>();
    HashMap<String, HashSet<String>> schedule = new HashMap<>();

    try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
      String line;
      while ((line = br.readLine()) != null) {
        String[] parts = line.split(":");
        if (parts.length == 2) {
          String name = parts[0].trim();
          int hours = Integer.parseInt(parts[1].trim());
          if (name.startsWith("Doctor")) {
            doctors.put(name, hours);
            schedule.put(name, new HashSet<>());
          } else if (name.startsWith("Patient")) {
            patients.put(name, hours);
          }
        }
      }
    } catch (IOException e) {
      System.err.println("Error reading file: " + e.getMessage());
      return;
    }

    // Call the schedulePatients method and print the result.
    boolean result = schedulePatients(doctors, patients, schedule);
    System.out.println("Can all patients be scheduled? " + result);

    // If the schedule is successful, print the final schedule.
    if (result) {
      System.out.println("Final Schedule:");
      for (String doctor : schedule.keySet()) {
        HashSet<String> assignedPatients = schedule.get(doctor);
        System.out.println(doctor + " sees patients: " + assignedPatients);
      }
    }
  }

  public static boolean schedulePatients(
      HashMap<String, Integer> doctors,
      HashMap<String, Integer> patients,
      HashMap<String, HashSet<String>> schedule) {

    // Base case: If all patients are scheduled, return true.
    if (patients.isEmpty()) {
      return true;
    }

    // Try assigning each patient to each doctor and recursively check the result.
    for (String doctor : doctors.keySet()) {
      for (String patient : patients.keySet()) {
        int doctorHours = doctors.get(doctor);
        int patientHours = patients.get(patient);

        // If the doctor has enough hours for the patient, assign the patient.
        if (doctorHours >= patientHours) {
          // Update doctor's available hours and patient's remaining hours.
          doctors.put(doctor, doctorHours - patientHours);
          patients.remove(patient);

          // Update the schedule.
          HashSet<String> assignedPatients = schedule.get(doctor);
          assignedPatients.add(patient);

          // Recursively try to schedule the remaining patients.
          if (schedulePatients(doctors, patients, schedule)) {
            return true; // Successful schedule found.
          }

          // Backtrack: Undo the changes for the next iteration.
          doctors.put(doctor, doctorHours);
          patients.put(patient, patientHours);
          assignedPatients.remove(patient);
        }
      }
    }

    // If no valid schedule is found, return false.
    return false;
  }
}
