import java.util.*;

public class DisasterManagementPrimsAlgorithm {

  public static class Edge {
    String source;
    String destination;
    int weight;

    public Edge(String source, String destination, int weight) {
      this.source = source;
      this.destination = destination;
      this.weight = weight;
    }
  }

  public static class Graph {
    HashMap<String, List<Edge>> adjacencyList = new HashMap<>();

    public void addEdge(String source, String destination, int weight) {
      Edge edge = new Edge(source, destination, weight);
      adjacencyList.computeIfAbsent(source, k -> new ArrayList<>()).add(edge);
      adjacencyList.computeIfAbsent(destination, k -> new ArrayList<>()).add(edge);
    }

    public List<Edge> primMST() {
      List<Edge> mst = new ArrayList<>();
      HashSet<String> visited = new HashSet<>();

      if (!adjacencyList.isEmpty()) {
        String startNode = adjacencyList.keySet().iterator().next();
        visited.add(startNode);

        while (visited.size() < adjacencyList.size()) {
          Edge minEdge = null;
          int minWeight = Integer.MAX_VALUE;

          for (String visitedNode : visited) {
            List<Edge> neighbors = adjacencyList.get(visitedNode);
            for (Edge neighbor : neighbors) {
              String nextNode = neighbor.source.equals(visitedNode) ? neighbor.destination : neighbor.source;
              if (!visited.contains(nextNode) && neighbor.weight < minWeight) {
                minEdge = neighbor;
                minWeight = neighbor.weight;
              }
            }
          }

          if (minEdge != null) {
            mst.add(minEdge);
            visited.add(minEdge.source);
            visited.add(minEdge.destination);
          }
        }
      }

      return mst;
    }
  }

  public static void main(String[] args) {
    // Example usage
    Graph roadNetwork = new Graph();
    roadNetwork.addEdge("Seattle", "Portland", 2);
    roadNetwork.addEdge("Seattle", "Butte", 4);
    roadNetwork.addEdge("Portland", "Butte", 1);
    roadNetwork.addEdge("Butte", "Salt Lake City", 3);

    List<Edge> minimumSpanningTree = roadNetwork.primMST();

    System.out.println("Minimum Spanning Tree:");
    for (Edge edge : minimumSpanningTree) {
      System.out.println(edge.source + " - " + edge.destination + " : " + edge.weight);
    }
  }
}
