import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class DoctorPatientSchedulerWithSpecialities {

  public static void main(String[] args) {
    // Prompt the user for the name of the text file
    // containing the patient and doctor data.
    // For example, "input.txt".
    System.out.println("Enter the name of the text file:");
    String fileName = System.console().readLine();

    // Read data from the text file and populate doctors and patients maps.
    HashMap<String, Doctor> doctors = new HashMap<>();
    HashMap<String, Patient> patients = new HashMap<>();
    HashMap<String, HashSet<String>> schedule = new HashMap<>();

    try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
      String line;
      while ((line = br.readLine()) != null) {
        String[] parts = line.split(":");
        if (parts.length == 3) {
          String name = parts[0].trim();
          int hours = Integer.parseInt(parts[1].trim());
          String specialty = parts[2].trim();
          if (name.startsWith("Doctor")) {
            doctors.put(name, new Doctor(name, hours, specialty));
            schedule.put(name, new HashSet<>());
          } else if (name.startsWith("Patient")) {
            patients.put(name, new Patient(name, hours, specialty));
          }
        }
      }
    } catch (IOException e) {
      System.err.println("Error reading file: " + e.getMessage());
      return;
    }

    // Call the schedulePatientsWithSpecialties method and print the result.
    boolean result = schedulePatientsWithSpecialties(doctors, patients, schedule);
    System.out.println("Can all patients be scheduled? " + result);

    // If the schedule is successful, print the final schedule.
    if (result) {
      System.out.println("Final Schedule:");
      for (String doctor : schedule.keySet()) {
        HashSet<String> assignedPatients = schedule.get(doctor);
        System.out.println(doctor + " sees patients: " + assignedPatients);
      }
    }
  }

  public static boolean schedulePatientsWithSpecialties(
      HashMap<String, Doctor> doctors,
      HashMap<String, Patient> patients,
      HashMap<String, HashSet<String>> schedule) {

    // Base case: If all patients are scheduled, return true.
    if (patients.isEmpty()) {
      return true;
    }

    // Create a copy of the patients set to avoid ConcurrentModificationException
    Set<String> patientNames = new HashSet<>(patients.keySet());

    // Try assigning each patient to each doctor and recursively check the result.
    for (String doctorName : doctors.keySet()) {
      Doctor doctor = doctors.get(doctorName);
      for (String patientName : patientNames) {
        Patient patient = patients.get(patientName);

        // If the doctor has enough hours and the right specialty for the patient,
        // assign the patient.
        if (doctor.getAvailableHours() >= patient.getRequiredHours() &&
            doctor.getSpecialty().equals(patient.getSpecialty())) {

          // Update doctor's available hours and patient's remaining hours.
          doctor.setAvailableHours(doctor.getAvailableHours() - patient.getRequiredHours());
          patients.remove(patientName);

          // Update the schedule.
          HashSet<String> assignedPatients = schedule.get(doctorName);
          assignedPatients.add(patientName);

          // Recursively try to schedule the remaining patients.
          if (schedulePatientsWithSpecialties(doctors, patients, schedule)) {
            return true; // Successful schedule found.
          }

          // Backtrack: Undo the changes for the next iteration.
          doctor.setAvailableHours(doctor.getAvailableHours() + patient.getRequiredHours());
          patients.put(patientName, patient);
          assignedPatients.remove(patientName);
        }
      }
    }

    // If no valid schedule is found, return false.
    return false;
  }

  static class Doctor {
    private String name;
    private int availableHours;
    private String specialty;

    public Doctor(String name, int availableHours, String specialty) {
      this.name = name;
      this.availableHours = availableHours;
      this.specialty = specialty;
    }

    public String getName() {
      return name;
    }

    public int getAvailableHours() {
      return availableHours;
    }

    public void setAvailableHours(int availableHours) {
      this.availableHours = availableHours;
    }

    public String getSpecialty() {
      return specialty;
    }
  }

  static class Patient {
    private String name;
    private int requiredHours;
    private String specialty;

    public Patient(String name, int requiredHours, String specialty) {
      this.name = name;
      this.requiredHours = requiredHours;
      this.specialty = specialty;
    }

    public String getName() {
      return name;
    }

    public int getRequiredHours() {
      return requiredHours;
    }

    public String getSpecialty() {
      return specialty;
    }
  }
}
