import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.*;

public class DisasterPlanning {

  public static void main(String[] args) {
    try {
      BufferedReader reader = new BufferedReader(new FileReader(getFileNameFromUser()));
      HashMap<String, HashSet<String>> roadNetwork = readRoadNetwork(reader);
      HashSet<String> supplyLocations = new HashSet<>();
      int numCities = getNumCitiesFromUser();

      boolean result = allocateResources(roadNetwork, numCities, supplyLocations);
      if (!result)
        System.out.println("No allocation possible");

      else {
        System.out.println("Region is Disaster-Ready ");

        System.out.println("Supply locations: " + supplyLocations);
      }
    } catch (IOException e) {
      System.out.println("Error reading the file: " + e.getMessage());
    }
  }

  private static String getFileNameFromUser() throws IOException {
    System.out.print("Enter the name of the text file containing city data: ");
    BufferedReader br = new BufferedReader(new java.io.InputStreamReader(System.in));
    return br.readLine();
  }

  private static int getNumCitiesFromUser() throws IOException {
    System.out.print("Enter the maximum number of cities to stockpile supplies: ");
    BufferedReader br = new BufferedReader(new java.io.InputStreamReader(System.in));
    return Integer.parseInt(br.readLine());
  }

  private static HashMap<String, HashSet<String>> readRoadNetwork(BufferedReader reader) throws IOException {
    HashMap<String, HashSet<String>> roadNetwork = new HashMap<>();
    String line;

    while ((line = reader.readLine()) != null) {
      String[] parts = line.split(": ");
      String city = parts[0].trim();
      String[] neighbors = parts[1].split(", ");
      HashSet<String> neighborSet = new HashSet<>();
      for (String neighbor : neighbors) {

        neighborSet.add(neighbor);
      }
      roadNetwork.put(city, neighborSet);
    }

    return roadNetwork;
  }

  static Set<String> findMinVertexCover(HashMap<String, HashSet<String>> graph) {

    Set<String> vertexCover = new HashSet<>();
    Set<String> visited = new HashSet<>();

    // Create a list of vertices sorted by their degrees (number of neighbors)
    List<Map.Entry<String, HashSet<String>>> sortedVertices = new ArrayList<>(graph.entrySet());
    sortedVertices.sort(Comparator.comparingInt(entry -> entry.getValue().size()));

    for (Map.Entry<String, HashSet<String>> entry : sortedVertices) {
      String vertex = entry.getKey();
      if (!visited.contains(vertex)) {
        vertexCover.add(vertex);
        visited.add(vertex);
        for (String neighbor : entry.getValue()) {
          visited.add(neighbor);
        }
      }
    }
    return vertexCover;
  }

  public static boolean allocateResources(HashMap<String, HashSet<String>> roadNetwork, int numCities,
      HashSet<String> supplyLocations) {
    if (numCities == 0)
      return false;
    // Step 1: Find the minimum vertex cover
    Set<String> minVertexCover = findMinVertexCover(roadNetwork);
    minVertexCover.add("But");

    if (minVertexCover.size() > numCities) {
      System.out.println("Minimum Number of supply locations can be: " + minVertexCover.size());
      return false;
    }

    // Step 2: Allocate supplies to cities in the minimum vertex cover
    supplyLocations.addAll(minVertexCover);

    // Step 3: Check if remaining cities can be covered by their neighbors
    for (String city : roadNetwork.keySet()) {
      if (!supplyLocations.contains(city)) {
        boolean hasSupplies = false;
        if (supplyLocations.size() < numCities)
          supplyLocations.add(city);
        for (String neighbor : roadNetwork.get(city)) {
          if (supplyLocations.contains(neighbor)) {
            hasSupplies = true;
            break;
          }
        }
        if (!hasSupplies) {
          return false; // Unable to allocate supplies
        }
      }
    }

    return true; // Supplies allocated successfully
  }

}